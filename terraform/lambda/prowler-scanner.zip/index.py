// Placeholder for prowler-scanner Lambda
